package com.inzent.ecm.confControl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfControlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfControlApplication.class, args);
		System.out.println("TEST");

	

	}

}
